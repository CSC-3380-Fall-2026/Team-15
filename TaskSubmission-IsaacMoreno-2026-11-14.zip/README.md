# Isaac Moreno task source files

Submission date: November 14, 2026.

- RoomLoader: Main.cs LoadRoom builds walls, obstacles and enemy spawns from level data.
- RoomFlow: Main.cs handles gates, enemy-clear checks and linked-room transitions.
- AbilitySystem: Player.cs handles skill cooldowns, mana costs and regeneration. GameData.cs and classes_skills.json define the skill data.

These are unmodified source snapshots from the local EditableGame project, packaged for review. They depend on the rest of that project and are not a standalone build or an integrated change to Team-15. Main.cs appears in both room task folders because it implements both features.

Attribution: the local project README states that code and vector assets were generated with Codex. This package does not claim newly authored code or newly completed integration. No tests were rerun for this packaging-only submission.
